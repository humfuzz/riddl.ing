import{a as t}from"../chunks/entry.U9t8C6mk.js";export{t as start};
