import{a as t}from"../chunks/entry.vShu07IW.js";export{t as start};
