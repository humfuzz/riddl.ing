import{l as o,a as r}from"../chunks/D34a1HlA.js";export{o as load_css,r as start};
