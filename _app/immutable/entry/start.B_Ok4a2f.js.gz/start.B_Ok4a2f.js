import{a as t}from"../chunks/entry.BBoF_1nt.js";export{t as start};
