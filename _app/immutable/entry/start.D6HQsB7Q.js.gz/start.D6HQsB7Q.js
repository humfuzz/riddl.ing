import{a as t}from"../chunks/entry.BGPc4HcE.js";export{t as start};
