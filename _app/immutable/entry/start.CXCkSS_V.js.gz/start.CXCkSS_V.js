import{a as t}from"../chunks/entry.Dl7TNCe4.js";export{t as start};
