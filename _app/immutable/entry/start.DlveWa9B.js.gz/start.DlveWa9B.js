import{a as t}from"../chunks/entry.M6OonecN.js";export{t as start};
