import{a as t}from"../chunks/entry.Bh818TI4.js";export{t as start};
