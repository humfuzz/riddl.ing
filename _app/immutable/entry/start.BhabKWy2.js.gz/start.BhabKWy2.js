import{a as t}from"../chunks/entry.CZgc_hWC.js";export{t as start};
