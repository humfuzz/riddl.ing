import{a as t}from"../chunks/entry.DT9djyKd.js";export{t as start};
