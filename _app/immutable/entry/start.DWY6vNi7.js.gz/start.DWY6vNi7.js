import{a as t}from"../chunks/entry.B0DLmbt2.js";export{t as start};
