import{a as t}from"../chunks/entry.Bo4cPNJO.js";export{t as start};
