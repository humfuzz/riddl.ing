import{a as t}from"../chunks/entry.9goLaDZG.js";export{t as start};
