import{a as t}from"../chunks/entry.BH3mBRTb.js";export{t as start};
