import{a as t}from"../chunks/entry.D5n9BC1U.js";export{t as start};
