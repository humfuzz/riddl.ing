import{a as t}from"../chunks/entry.CdHf4K1m.js";export{t as start};
