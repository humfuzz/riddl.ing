import{a as t}from"../chunks/entry.B5HXRMXm.js";export{t as start};
