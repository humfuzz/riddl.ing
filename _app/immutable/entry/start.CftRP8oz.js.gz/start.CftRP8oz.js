import{a as t}from"../chunks/entry.D41IVW8d.js";export{t as start};
