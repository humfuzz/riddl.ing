import{a as t}from"../chunks/entry.DD0C5fwL.js";export{t as start};
