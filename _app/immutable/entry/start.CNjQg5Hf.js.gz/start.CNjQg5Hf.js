import{a as t}from"../chunks/entry.BRfSU7QL.js";export{t as start};
