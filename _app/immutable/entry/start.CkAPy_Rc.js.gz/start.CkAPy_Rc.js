import{a as t}from"../chunks/entry.DhVZ4FzR.js";export{t as start};
