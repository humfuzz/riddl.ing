import{a as t}from"../chunks/entry.BSmBPsEb.js";export{t as start};
