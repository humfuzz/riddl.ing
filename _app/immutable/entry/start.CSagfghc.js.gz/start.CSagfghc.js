import{a as t}from"../chunks/entry.C_70VQBP.js";export{t as start};
