import{a as t}from"../chunks/entry.C1KzMr3C.js";export{t as start};
